Shader "Hidden/RAFT/AuthoredFFTCoordinateProbe" {
Properties { _ProbeTex ("Authored texels", 2D) = "white" {} }
SubShader {
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(0.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.Sample(sampler_ProbeTex, i.uv) * 1.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(1.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.Sample(sampler_ProbeTex, float4(i.uv.yx, 0.25, 0.75).yx) * 2.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(2.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.SampleLevel(sampler_ProbeTex, asfloat(asuint(i.uv) ^ uint2(0u, 0x80000000u)), 0.0) * 3.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(3.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.Sample(sampler_ProbeTex, float2(asfloat(asint(i.uv.x) ^ (-2147483647 - 1)), i.uv.y)) * 4.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(4.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.SampleLevel(sampler_ProbeTex, float2(int2(i.uv * 4.0)) * 0.25, 0.0) * 5.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(5.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.SampleLevel(sampler_ProbeTex, float2(uint2(abs(i.uv) * 4.0)) * 0.25, 0.0) * 6.0/8.0; }

ENDHLSL
}
Pass { Cull Off ZWrite Off ZTest Always
HLSLPROGRAM
#pragma target 5.0
#pragma vertex gt_vs_main
#pragma fragment gt_fs_main
Texture2D<float4> _ProbeTex;
SamplerState sampler_ProbeTex;
struct Input { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
struct Varying { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
Varying gt_vs_main(Input v) { Varying o; o.pos=v.vertex; o.uv=v.uv+float2(6.0/16.0,0.0); return o; }
float4 gt_fs_main(Varying i) : SV_Target { return _ProbeTex.Load(int3(int2(i.uv * 4.0), 0)) * 7.0/8.0; }

ENDHLSL
}
}
Fallback Off
}
