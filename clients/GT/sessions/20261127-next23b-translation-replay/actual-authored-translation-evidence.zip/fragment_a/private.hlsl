static float4 o0;

struct SPIRV_Cross_Output
{
    float4 o0 : SV_Target0;
};

void frag_main()
{
    o0 = float4(0.125f, 0.25f, 0.5f, 1.0f);
}

SPIRV_Cross_Output main()
{
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.o0 = o0;
    return stage_output;
}
