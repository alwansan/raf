float4 main() : SV_Target { return float4(0.125, 0.25, 0.5, 1.0); }
