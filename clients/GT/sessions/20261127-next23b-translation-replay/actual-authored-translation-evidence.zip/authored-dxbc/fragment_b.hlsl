float4 main() : SV_Target { return float4(0.75, 0.5, 0.25, 1.0); }
