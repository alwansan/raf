#if !defined(GT_AUTHORED_ALT)
cbuffer GT_CBufferA {
float4 GT_TintA : packoffset(c0.x);
};
SamplerState sampler_GT_TexA;
Texture2D<float4> _GT_TexA;
static float4 gt_vs_gl_Position;
static float4 gt_vs_v0;

struct gt_vs_SPIRV_Cross_Input
{
    float4 gt_vs_v0 : POSITION0;
};

struct gt_vs_SPIRV_Cross_Output
{
    float4 gt_vs_gl_Position : SV_Position;
};

void vert_main()
{
    gt_vs_gl_Position = gt_vs_v0;
}

gt_vs_SPIRV_Cross_Output gt_vs_main(gt_vs_SPIRV_Cross_Input stage_input)
{
    gt_vs_v0 = stage_input.gt_vs_v0;
    vert_main();
    gt_vs_SPIRV_Cross_Output stage_output;
    stage_output.gt_vs_gl_Position = gt_vs_gl_Position;
    return stage_output;
}


float4 gt_fs_raft921_cb0_read(uint index) {
switch (index) {
case 0: return float4(GT_TintA.x, GT_TintA.y, GT_TintA.z, GT_TintA.w);
default: return float4(0, 0, 0, 0);
}
}




static float4 gt_fs_o0;

struct gt_fs_SPIRV_Cross_Output
{
    float4 gt_fs_o0 : SV_Target0;
};

void frag_main()
{
    float4 r0 = _GT_TexA.Sample(sampler_GT_TexA, float4(0.25f, 0.75f, 0.0f, 0.0f).xy);
    gt_fs_o0 = r0 * gt_fs_raft921_cb0_read(0u);
}

gt_fs_SPIRV_Cross_Output gt_fs_main()
{
    frag_main();
    gt_fs_SPIRV_Cross_Output stage_output;
    stage_output.gt_fs_o0 = gt_fs_o0;
    return stage_output;
}

#elif defined(GT_AUTHORED_ALT)
cbuffer GT_CBufferB {
float4 GT_TintB : packoffset(c0.x);
};
SamplerState sampler_GT_TexB;
Texture2D<float4> _GT_TexB;
static float4 gt_vs_gl_Position;
static float4 gt_vs_v0;

struct gt_vs_SPIRV_Cross_Input
{
    float4 gt_vs_v0 : POSITION0;
};

struct gt_vs_SPIRV_Cross_Output
{
    float4 gt_vs_gl_Position : SV_Position;
};

void vert_main()
{
    gt_vs_gl_Position = gt_vs_v0;
}

gt_vs_SPIRV_Cross_Output gt_vs_main(gt_vs_SPIRV_Cross_Input stage_input)
{
    gt_vs_v0 = stage_input.gt_vs_v0;
    vert_main();
    gt_vs_SPIRV_Cross_Output stage_output;
    stage_output.gt_vs_gl_Position = gt_vs_gl_Position;
    return stage_output;
}


float4 gt_fs_raft921_cb0_read(uint index) {
switch (index) {
case 0: return float4(GT_TintB.x, GT_TintB.y, GT_TintB.z, GT_TintB.w);
default: return float4(0, 0, 0, 0);
}
}




static float4 gt_fs_o0;

struct gt_fs_SPIRV_Cross_Output
{
    float4 gt_fs_o0 : SV_Target0;
};

void frag_main()
{
    float4 r0 = _GT_TexB.Sample(sampler_GT_TexB, float4(0.25f, 0.75f, 0.0f, 0.0f).xy);
    gt_fs_o0 = r0 * gt_fs_raft921_cb0_read(0u);
}

gt_fs_SPIRV_Cross_Output gt_fs_main()
{
    frag_main();
    gt_fs_SPIRV_Cross_Output stage_output;
    stage_output.gt_fs_o0 = gt_fs_o0;
    return stage_output;
}

#else
cbuffer GT_CBufferA {
float4 GT_TintA : packoffset(c0.x);
};
SamplerState sampler_GT_TexA;
Texture2D<float4> _GT_TexA;
static float4 gt_vs_gl_Position;
static float4 gt_vs_v0;

struct gt_vs_SPIRV_Cross_Input
{
    float4 gt_vs_v0 : POSITION0;
};

struct gt_vs_SPIRV_Cross_Output
{
    float4 gt_vs_gl_Position : SV_Position;
};

void vert_main()
{
    gt_vs_gl_Position = gt_vs_v0;
}

gt_vs_SPIRV_Cross_Output gt_vs_main(gt_vs_SPIRV_Cross_Input stage_input)
{
    gt_vs_v0 = stage_input.gt_vs_v0;
    vert_main();
    gt_vs_SPIRV_Cross_Output stage_output;
    stage_output.gt_vs_gl_Position = gt_vs_gl_Position;
    return stage_output;
}


float4 gt_fs_raft921_cb0_read(uint index) {
switch (index) {
case 0: return float4(GT_TintA.x, GT_TintA.y, GT_TintA.z, GT_TintA.w);
default: return float4(0, 0, 0, 0);
}
}




static float4 gt_fs_o0;

struct gt_fs_SPIRV_Cross_Output
{
    float4 gt_fs_o0 : SV_Target0;
};

void frag_main()
{
    float4 r0 = _GT_TexA.Sample(sampler_GT_TexA, float4(0.25f, 0.75f, 0.0f, 0.0f).xy);
    gt_fs_o0 = r0 * gt_fs_raft921_cb0_read(0u);
}

gt_fs_SPIRV_Cross_Output gt_fs_main()
{
    frag_main();
    gt_fs_SPIRV_Cross_Output stage_output;
    stage_output.gt_fs_o0 = gt_fs_o0;
    return stage_output;
}

#endif

