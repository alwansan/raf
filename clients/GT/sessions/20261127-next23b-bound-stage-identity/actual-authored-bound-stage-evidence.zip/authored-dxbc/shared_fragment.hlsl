Texture2D tex:register(t0); SamplerState samp:register(s0); cbuffer Params:register(b0){float4 tint;}; float4 main():SV_Target{return tex.Sample(samp,float2(0.25,0.75))*tint;}
