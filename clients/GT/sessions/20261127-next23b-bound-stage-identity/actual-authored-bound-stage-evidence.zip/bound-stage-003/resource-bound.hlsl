cbuffer cb1_struct : register(b0)
{
    float4 cb0_0_m0[1] : packoffset(c0);
};

SamplerState sampler_GT_TexB : register(s1);
Texture2D<float4> _GT_TexB : register(t2);

static float4 o0;

struct SPIRV_Cross_Output
{
    float4 o0 : SV_Target0;
};

void frag_main()
{
    float4 r0 = _GT_TexB.Sample(sampler_GT_TexB, float4(0.25f, 0.75f, 0.0f, 0.0f).xy);
    o0 = r0 * cb0_0_m0[0u];
}

SPIRV_Cross_Output main()
{
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.o0 = o0;
    return stage_output;
}
