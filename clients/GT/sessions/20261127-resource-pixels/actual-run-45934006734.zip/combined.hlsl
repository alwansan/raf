Texture2D<float4> _MainTex;
SamplerState sampler_MainTex;


struct AuthoredInput { float4 pos : POSITION; float2 uv : TEXCOORD0; };
struct AuthoredOutput { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; float marker : TEXCOORD1; };
AuthoredOutput gt_vs_main(AuthoredInput i) {
    AuthoredOutput o; o.pos = i.pos; o.uv = i.uv;
    o.marker = _MainTex.SampleLevel(sampler_MainTex, float2(0.625, 0.5), 0.0).r;
    return o;
}



float4 gt_fs_main(float2 uv : TEXCOORD0, float marker : TEXCOORD1) : SV_Target0 {
    float4 c = _MainTex.Sample(sampler_MainTex, uv); return float4(marker, c.gba);
}
