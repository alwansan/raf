"""Isolated synthetic reproduction of RAFT 921 stage_parameter_records binding-list logic.
No original shader metadata, asset content, Unity or Vulkan is loaded.
"""
import json, re, unittest
from pathlib import Path

OLD = re.compile(r'\b(Texture\w*(?:\s*<[^;{}>]+>)?|SamplerState|SamplerComparisonState)\s+([A-Za-z_]\w*)\s*:\s*register\(\s*([ts])(\d+)\s*\)\s*;')
NEW = re.compile(r'\b(Texture\w*(?:\s*<[^;{}>]+>)?|SamplerState|SamplerComparisonState)\s+([A-Za-z_]\w*)\s*:\s*register\(\s*([ts])(\d+)\s*(?:,\s*space(\d+)\s*)?\)\s*;')
REGISTER = re.compile(r'\bregister\s*\(\s*[ts]\d+\s*,\s*space\d+\s*\)')
IDENT = re.compile(r'[A-Za-z_]\w*\Z')

def enumerate_stage(source, textures, resource_pattern):
    """Isolated contract of the loop in stage_parameter_records; explicit provenance check."""
    bindings=[]
    matches=list(resource_pattern.finditer(source))
    all_declarations=re.findall(r'\b(?:Texture2D|SamplerState|SamplerComparisonState)\s+\w+\s*:\s*register\s*\([^)]*\)\s*;', source)
    if len(matches)!=len(all_declarations):
        raise ValueError('unparsed_texture_or_sampler_declaration')
    seen_symbol=set(); seen_slot=set(); seen_target=set()
    for match in matches:
        variable,kind=match[2],match[3]
        slot_match=re.fullmatch(kind+r'(\d+)',variable)
        if not slot_match:
            raise ValueError('original_texture_or_sampler_slot_missing')
        if match.re is NEW and match[5] is not None and int(match[5]) != 0:
            raise ValueError('nonzero_register_space_disallowed')
        slot=int(slot_match[1]); key=(kind,slot)
        if key in seen_slot or variable in seen_symbol:
            raise ValueError('duplicate_original_resource_slot')
        seen_slot.add(key);seen_symbol.add(variable)
        candidates=([textures[slot][0]] if slot in textures else []) if kind=='t' else [name for name,sampler in textures.values() if sampler==slot]
        if len(candidates)!=1 or not IDENT.fullmatch(candidates[0]):
            raise ValueError('original_texture_or_sampler_binding_ambiguous')
        target=('sampler'+candidates[0]) if kind=='s' else candidates[0]
        if target in seen_target:
            raise ValueError('ambiguous_target_identifier')
        seen_target.add(target)
        bindings.append({'kind':kind,'slot':slot,'source_texture_name':candidates[0]})
    return bindings

TEX={3:('_MainTex',7)}
BARE='Texture2D t3 : register(t21);\nSamplerState s7 : register(s16);'
SPACE='Texture2D t3 : register(t21, space0);\nSamplerState s7 : register(s16, space0);'
EXPECTED=[{'kind':'t','slot':3,'source_texture_name':'_MainTex'},{'kind':'s','slot':7,'source_texture_name':'_MainTex'}]

class EnumerationTests(unittest.TestCase):
    def test_old_bare_works(self):self.assertEqual(enumerate_stage(BARE,TEX,OLD),EXPECTED)
    def test_old_explicit_space_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'unparsed'):enumerate_stage(SPACE,TEX,OLD)
    def test_new_bare_and_space_agree(self):
        self.assertEqual(enumerate_stage(BARE,TEX,NEW),EXPECTED)
        self.assertEqual(enumerate_stage(SPACE,TEX,NEW),EXPECTED)
    def test_compiled_registers_are_not_original_slots(self):
        self.assertEqual(enumerate_stage(SPACE,TEX,NEW),EXPECTED)
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE,{21:('_MainTex',16)},NEW)
    def test_valid_sampler_other_original_slot_rejected(self):
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE,{3:('_MainTex',16)},NEW)
    def test_duplicate_slot(self):
        with self.assertRaisesRegex(ValueError,'duplicate'):enumerate_stage(SPACE+'\nTexture2D t3 : register(t22, space0);',TEX,NEW)
    def test_duplicate_target_two_slots(self):
        with self.assertRaisesRegex(ValueError,'ambiguous_target'):enumerate_stage(SPACE+'\nTexture2D t4 : register(t22);',{3:('_MainTex',7),4:('_MainTex',8)},NEW)
    def test_nonzero_space_texture(self):
        with self.assertRaisesRegex(ValueError,'nonzero'):enumerate_stage(SPACE.replace('t21, space0','t21, space1'),TEX,NEW)
    def test_nonzero_space_sampler(self):
        with self.assertRaisesRegex(ValueError,'nonzero'):enumerate_stage(SPACE.replace('s16, space0','s16, space2'),TEX,NEW)
    def test_invalid_source_property(self):
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE,{3:('3Bad',7)},NEW)
    def test_unsupported_resource_shape(self):
        with self.assertRaisesRegex(ValueError,'unparsed'):enumerate_stage(SPACE.replace('register(t21, space0)','register(t21, space 0)'),TEX,NEW)
    def test_sampler_collision_two_texture_names(self):
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE,{3:('_MainTex',7),4:('_Detail',7)},NEW)
    def test_declared_unknown_resource_slot(self):
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE.replace('t3','t9'),TEX,NEW)
    def test_sampler_missing(self):
        with self.assertRaisesRegex(ValueError,'ambiguous'):enumerate_stage(SPACE.replace('s7','s8'),TEX,NEW)
    def test_symbols_semantics_unchanged(self):
        sample='float4 main() : SV_Target { return t3.Sample(s7, float2(.5,.5)); }'
        self.assertIn('t3.Sample(s7',sample)
        self.assertEqual(enumerate_stage(SPACE+'\n'+sample,TEX,NEW),EXPECTED)

if __name__=='__main__':
    unittest.main(verbosity=2)
